package Paarthis.CallHub;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class TC001_Login_CreateContact {
    WebDriver driver;

    @BeforeMethod
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("https://app.callhub.io/login/");
    }

    @Test
    public void testCreateContactList() throws IOException, InterruptedException {
    	
    	FileReader reader=new FileReader(System.getProperty("user.dir")+"\\Config.properties");  
		Properties p=new Properties();  
		p.load(reader); 
		
        // Objects for the page class files
        LoginPage loginPage = new LoginPage(driver);
        DashboardPage dashboardPage = new DashboardPage(driver);
        ContactListPage contactsPage = new ContactListPage(driver);        
        
        
        // Execution of the code
        loginPage.login(p.getProperty("Username"), p.getProperty("Password"));
        contactsPage.createContactList("ContactList");
        dashboardPage.navigateToDashboard();
        dashboardPage.createCampaign();

    }

    @AfterMethod
    public void teardown() {
        driver.quit();
    }
}


