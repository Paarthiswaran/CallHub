package Paarthis.CallHub;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
    WebDriver driver;

    // All element's Xpath on Login Page
    
    public String UsernameXpath = "//*[@id=\"id_user\"]";
    public String NextBtnXpath = "//*[@id=\"change-btn-text\"]";
    public String PasswordXpath = "//*[@id=\"id_password\"]";
    public String SignInBtnXpath = "//*[@id=\"change-btn-text\"]";
    public String CreateCampaignXpath = "//*[@id=\"newCampaignCreation\"]/div[1]/a";
    
    public LoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    //All methods written in Login Page
    
    public void login(String username, String password) throws InterruptedException {
    	
    	driver.findElement(By.xpath(UsernameXpath)).sendKeys(username);
    	driver.findElement(By.xpath(NextBtnXpath)).click();
    	driver.findElement(By.xpath(PasswordXpath)).sendKeys(password);
    	driver.findElement(By.xpath(SignInBtnXpath)).click();
    	Thread.sleep(3000);
    	driver.findElement(By.xpath(CreateCampaignXpath)).isDisplayed();
    }
}

