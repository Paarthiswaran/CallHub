package Paarthis.CallHub;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DashboardPage {
    WebDriver driver;

    public String CreateCampaignXpath = "//*[@id=\"newCampaignCreation\"]/div[1]/a";
    public String ClickDashboardXpath = "//a[contains(text(),'Dashboard')]";
    public String NextBtnXpath = "//*[@id=\"createCampaign\"]";
    public String TextToSpeech ="(//i[@class='radio'])[5]";
    public String TextBox = "//*[@id=\"id_live-question\"]";
    public String AddTransferXpath = "//button[@class='btn' and contains(text(), 'Add Transfer')]";
    public String ChooseTextToSpeech = "(//*[@id=\"vb-transfer-tts-label\"]/text())[3]";
    public String ChooseAudioDrpDwnXpath = "//*[@id=\"select2-audio-select-container\"]";
  //*[@id="select2-audio-select-result-p326-3504043130716423901"]
    public String ChooseSampleAudioXpath = "//li[contains(text(), 'sample-audio-voice-broadcast')]";
    public String NoToTransferBoxXpath = "//*[@id=\"id_transfer-phone_number\"]";
    public String AddTransferBtnXpath = "//*[@id=\"transfer-add-btn\"]";
    public String NxtBtnXpath = "//*[@id=\"wizard-next\"]";
    public String ContactListDrpDwnXpath = "//*[@id=\"phonebook-section\"]/div/div[3]/span[1]/span[1]/span";
    public String selectContactListXpath = "//li[contains(@class, 'select2-results__option') and text()='Test_Contact_List_1']";
    public String CampaignXpath = "//span[@class='Labelsecond-Span' and text()='Voice Broadcast Campaign']";
    
    
    
    public DashboardPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

 public void navigateToDashboard() {
    	
    	driver.findElement(By.xpath(ClickDashboardXpath)).click();
        
    }

    public void createCampaign() throws InterruptedException {
    	
    	driver.findElement(By.xpath(CreateCampaignXpath)).click();
    	driver.findElement(By.xpath(NextBtnXpath)).click();
    	driver.findElement(By.xpath(TextToSpeech)).click();
    	driver.findElement(By.xpath(TextBox)).click();
    	driver.findElement(By.xpath(TextBox)).sendKeys("Hi this is a test call from CallHub for QA Automation");  	
    	driver.findElement(By.xpath(AddTransferXpath)).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath(ChooseAudioDrpDwnXpath)).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath(ChooseSampleAudioXpath)).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath(NoToTransferBoxXpath)).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath(NoToTransferBoxXpath)).sendKeys("1234567899");
    	Thread.sleep(2000);
    	driver.findElement(By.xpath(AddTransferBtnXpath)).click();
    	Thread.sleep(2000);
    	
    	WebElement NxtBtn = driver.findElement(By.xpath(NxtBtnXpath));
    	JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", NxtBtn);

    	driver.findElement(By.xpath(NxtBtnXpath)).click();
    	driver.findElement(By.xpath(ContactListDrpDwnXpath)).click();	
    	driver.findElement(By.xpath(selectContactListXpath)).click();
    	driver.findElement(By.xpath(NxtBtnXpath)).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath(NxtBtnXpath)).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath(NxtBtnXpath)).click();
    	driver.findElement(By.xpath(CampaignXpath)).isDisplayed();
    }
}
