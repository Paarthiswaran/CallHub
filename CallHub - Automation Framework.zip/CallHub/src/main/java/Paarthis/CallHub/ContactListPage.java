package Paarthis.CallHub;

import java.text.SimpleDateFormat;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ContactListPage {
    WebDriver driver;

    // All element's Xpath on Contacts Page
    
   public String ContactsXpath = "//*[@id='contacts-dropdown']";
   public String ContactBookXpath = "//span[@class='phonebook-icon']";
   public String CreateContactListXpath = "//a[text()='Create contact list']";
   public String NameFieldXpath ="//*[@id=\"phonebook-form\"]/div[1]/div/input";
   public String NextAddContactBtnXpath = "//*[@id=\"create-phonebook-btn\"]";
   public String AddSingleContactBtnXpath = "//*[@id=\"open-adding-single-contact-modal\"]";
   
   public String AddFirstNameXpath = "//*[@id=\"create-contact-form\"]/div[1]/div[1]/div/input";
   public String EnterNumberXpath = "//*[@id=\"create-contact-form\"]/div[1]/div[3]/div/input";
   public String AddContactXpath = "//*[@id=\"create-contact-btn\"]";
   public String contactAddedXpath = "//tr[td[contains(text(), 'Test_User')]]";
   

	String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
   
    public ContactListPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // All methods written for Contacts page
    
    public void createContactList(String listName) throws InterruptedException {
    	
    	driver.findElement(By.xpath(ContactsXpath)).click();
    	driver.findElement(By.xpath(ContactBookXpath)).click();
    	driver.findElement(By.xpath(CreateContactListXpath)).click();
    	driver.findElement(By.xpath(NameFieldXpath)).sendKeys("Test_ContactList"+timeStamp);
    	driver.findElement(By.xpath(NextAddContactBtnXpath)).click();
    	driver.findElement(By.xpath(AddSingleContactBtnXpath)).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath(AddFirstNameXpath)).click();
    	driver.findElement(By.xpath(AddFirstNameXpath)).sendKeys("Test_User"+timeStamp);
    	Thread.sleep(2000);
    	driver.findElement(By.xpath(EnterNumberXpath)).click();
    	driver.findElement(By.xpath(EnterNumberXpath)).sendKeys("1234567890");
    	driver.findElement(By.xpath(AddContactXpath)).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath(contactAddedXpath)).isDisplayed();
        
    }
}
